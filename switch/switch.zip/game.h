#pragma once
void InitGame();
void UninitGame();
void UpdateGame();
void DrawGame();
