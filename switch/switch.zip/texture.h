#pragma once

unsigned int LoadTexture(const char *FileName);
void UnloadTexture(unsigned int Texture);
void SetTexture(unsigned int Texture);


