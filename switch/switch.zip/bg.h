#pragma once

void InitBG();
void UninitBG();
void UpdateBG();
void DrawBG();


