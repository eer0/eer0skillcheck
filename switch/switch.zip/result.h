#pragma once
#pragma once

void InitResult();
void UninitResult();
void UpdateResult();
void DrawResult();


