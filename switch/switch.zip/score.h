#pragma once
void InitScore();
void UninitScore();
void UpdateScore();
void DrawScore();
void AddScore(int score);