#pragma once

void InitTitle();
void UninitTitle();
void UpdateTitle();
void DrawTitle();


